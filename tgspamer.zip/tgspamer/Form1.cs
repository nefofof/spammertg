﻿using System.Data;
using System.Diagnostics;

namespace tgspamer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Thread.Sleep(2000);
            int i = 0;
            while (i < 50)
            {
                Thread.Sleep(4700);
                SendKeys.Send(richTextBox1.Text);
                SendKeys.Send("{ENTER}");
                Thread.Sleep(1500);
                SendKeys.Send(richTextBox2.Text);
                SendKeys.Send("{ENTER}");
                Thread.Sleep(2000);
                SendKeys.Send(richTextBox3.Text);
                SendKeys.Send("{ENTER}");
                i++;
                Thread.Sleep(2000);
            }
            Thread.Sleep(300000);
            SendKeys.Send("Назад");
            SendKeys.Send("{ENTER}");
            Thread.Sleep(2000);
            SendKeys.Send("👤Мой профиль");
            SendKeys.Send("{ENTER}");
            Thread.Sleep(2000);
            SendKeys.Send("🌇 Выбрать город");
            SendKeys.Send("{ENTER}");
            Thread.Sleep(2000);
            DataTable table = new DataTable();
            table.Columns.Add("города", typeof(string));
            table.Rows.Add(richTextBox4.Text);
            table.Rows.Add(richTextBox5.Text);
            table.Rows.Add(richTextBox6.Text);
            table.Rows.Add(richTextBox7.Text);
            table.Rows.Add(richTextBox8.Text);
            table.Rows.Add(richTextBox9.Text);
            Random random = new Random();
            int randomIndex = random.Next(table.Rows.Count);
            DataRow randomRow = table.Rows[randomIndex];
            string randomCity = randomRow["города"].ToString();
            SendKeys.Send(randomCity);
            SendKeys.Send("{ENTER}");
            Thread.Sleep(2500);
            SendKeys.Send("Назад");
            SendKeys.Send("{ENTER}");
            Thread.Sleep(2500);
            SendKeys.Send("🚀Оценивать");
            SendKeys.Send("{ENTER}");
            i = 0;

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            base.Capture = false;
            Message m = Message.Create(base.Handle, 0xa1, new IntPtr(2), IntPtr.Zero);
            this.WndProc(ref m);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "💌Сообщение";
            richTextBox2.Text = "Приветик, есть быстрый ворк чтобы заработать бабло, в соло я не справляюсь. Поэтому делюсь темой, пиши в лс и всё расскажу и доведу до профита";
            richTextBox3.Text = "10";
            richTextBox4.Text = "Харьков";
            richTextBox5.Text = "Чернигов";
            richTextBox6.Text = "Киев";
            richTextBox7.Text = "Винница";
            richTextBox8.Text = "Одесса";
            richTextBox9.Text = "Житомир";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "💌Сообщение";
            richTextBox2.Text = "Hi, there is a quick work to earn money, I can't do solo. Therefore, I share the way of earning money, write in private messages. I will tell you everything and bring it to profit  \n\n Приветик, есть быстрый ворк чтобы заработать бабло, в соло я не справляюсь. Поэтому делюсь темой, пиши в лс и всё расскажу и доведу до профита";
            richTextBox3.Text = "10";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Process.Start(new ProcessStartInfo("https://t.me/owned_1345") { UseShellExecute = true });
        }
    }
}
