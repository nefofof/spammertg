﻿namespace tgspamer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            label1 = new Label();
            button2 = new Button();
            richTextBox2 = new RichTextBox();
            richTextBox3 = new RichTextBox();
            button3 = new Button();
            button4 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            button5 = new Button();
            richTextBox1 = new RichTextBox();
            richTextBox4 = new RichTextBox();
            richTextBox5 = new RichTextBox();
            richTextBox6 = new RichTextBox();
            richTextBox7 = new RichTextBox();
            richTextBox8 = new RichTextBox();
            richTextBox9 = new RichTextBox();
            button6 = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Javanese Text", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Red;
            button1.Location = new Point(803, -1);
            button1.Name = "button1";
            button1.Size = new Size(36, 35);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("American Captain Cyrillic", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(208, 29);
            label1.TabIndex = 1;
            label1.Text = "Spammer TG v2.6";
            // 
            // button2
            // 
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Javanese Text", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(756, -1);
            button2.Name = "button2";
            button2.Size = new Size(41, 35);
            button2.TabIndex = 2;
            button2.Text = "---";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox2.ForeColor = Color.White;
            richTextBox2.Location = new Point(12, 95);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(428, 57);
            richTextBox2.TabIndex = 6;
            richTextBox2.Text = "Сюда то что будет спамиться людям";
            // 
            // richTextBox3
            // 
            richTextBox3.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox3.ForeColor = Color.White;
            richTextBox3.Location = new Point(12, 158);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.Size = new Size(200, 19);
            richTextBox3.TabIndex = 7;
            richTextBox3.Text = "Сюда оценку";
            richTextBox3.TextChanged += richTextBox3_TextChanged;
            // 
            // button3
            // 
            button3.FlatAppearance.BorderColor = Color.Lime;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("American Captain Cyrillic", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button3.ForeColor = Color.White;
            button3.Location = new Point(550, 318);
            button3.Name = "button3";
            button3.Size = new Size(289, 51);
            button3.TabIndex = 8;
            button3.Text = "Начать спам";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.FlatAppearance.BorderColor = Color.Red;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("American Captain Cyrillic", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button4.ForeColor = Color.White;
            button4.Location = new Point(255, 318);
            button4.Name = "button4";
            button4.Size = new Size(289, 51);
            button4.TabIndex = 9;
            button4.Text = "Закончить спам";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // button5
            // 
            button5.FlatAppearance.BorderColor = Color.FromArgb(35, 35, 35);
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("American Captain Cyrillic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button5.ForeColor = Color.FromArgb(150, 150, 150);
            button5.Location = new Point(12, 332);
            button5.Name = "button5";
            button5.Size = new Size(91, 31);
            button5.TabIndex = 10;
            button5.Text = "форма 1";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox1.ForeColor = Color.White;
            richTextBox1.Location = new Point(12, 67);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(200, 19);
            richTextBox1.TabIndex = 12;
            richTextBox1.Text = "💌Сообщение";
            // 
            // richTextBox4
            // 
            richTextBox4.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox4.ForeColor = Color.White;
            richTextBox4.Location = new Point(619, 79);
            richTextBox4.Name = "richTextBox4";
            richTextBox4.Size = new Size(200, 19);
            richTextBox4.TabIndex = 13;
            richTextBox4.Text = "Название города #1";
            // 
            // richTextBox5
            // 
            richTextBox5.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox5.ForeColor = Color.White;
            richTextBox5.Location = new Point(619, 104);
            richTextBox5.Name = "richTextBox5";
            richTextBox5.Size = new Size(200, 19);
            richTextBox5.TabIndex = 14;
            richTextBox5.Text = "Название города #2";
            // 
            // richTextBox6
            // 
            richTextBox6.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox6.ForeColor = Color.White;
            richTextBox6.Location = new Point(619, 129);
            richTextBox6.Name = "richTextBox6";
            richTextBox6.Size = new Size(200, 19);
            richTextBox6.TabIndex = 15;
            richTextBox6.Text = "Название города #3";
            // 
            // richTextBox7
            // 
            richTextBox7.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox7.ForeColor = Color.White;
            richTextBox7.Location = new Point(619, 199);
            richTextBox7.Name = "richTextBox7";
            richTextBox7.Size = new Size(200, 19);
            richTextBox7.TabIndex = 18;
            richTextBox7.Text = "Название города #6";
            // 
            // richTextBox8
            // 
            richTextBox8.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox8.ForeColor = Color.White;
            richTextBox8.Location = new Point(619, 174);
            richTextBox8.Name = "richTextBox8";
            richTextBox8.Size = new Size(200, 19);
            richTextBox8.TabIndex = 17;
            richTextBox8.Text = "Название города #5";
            // 
            // richTextBox9
            // 
            richTextBox9.BackColor = Color.FromArgb(35, 35, 35);
            richTextBox9.ForeColor = Color.White;
            richTextBox9.Location = new Point(619, 149);
            richTextBox9.Name = "richTextBox9";
            richTextBox9.Size = new Size(200, 19);
            richTextBox9.TabIndex = 16;
            richTextBox9.Text = "Название города #4";
            // 
            // button6
            // 
            button6.FlatAppearance.BorderColor = Color.FromArgb(35, 35, 35);
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("American Captain Cyrillic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button6.ForeColor = Color.FromArgb(150, 150, 150);
            button6.Location = new Point(653, 3);
            button6.Name = "button6";
            button6.Size = new Size(97, 31);
            button6.TabIndex = 19;
            button6.Text = "ТГ СОЗДАТЕЛЯ";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("American Captain Cyrillic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.FromArgb(150, 150, 150);
            label2.Location = new Point(211, 17);
            label2.Name = "label2";
            label2.Size = new Size(83, 17);
            label2.TabIndex = 20;
            label2.Text = "( бибинто )";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(35, 35, 35);
            ClientSize = new Size(851, 375);
            Controls.Add(label2);
            Controls.Add(button6);
            Controls.Add(richTextBox7);
            Controls.Add(richTextBox8);
            Controls.Add(richTextBox9);
            Controls.Add(richTextBox6);
            Controls.Add(richTextBox5);
            Controls.Add(richTextBox4);
            Controls.Add(richTextBox1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(richTextBox3);
            Controls.Add(richTextBox2);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Spammer TG by Owned1345";
            TopMost = true;
            Load += Form1_Load;
            MouseDown += Form1_MouseDown;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label1;
        private Button button2;
        private RichTextBox richTextBox3;
        private Button button3;
        private Button button4;
        private System.Windows.Forms.Timer timer1;
        private Button button5;
        public RichTextBox richTextBox2;
        public RichTextBox richTextBox1;
        public RichTextBox richTextBox4;
        public RichTextBox richTextBox5;
        public RichTextBox richTextBox6;
        public RichTextBox richTextBox7;
        public RichTextBox richTextBox8;
        public RichTextBox richTextBox9;
        private Button button6;
        private Label label2;
    }
}
